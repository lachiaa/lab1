public class Home {
    private String firstName;
    private String lastName;
    private int footage;
    private double dwelling;
    private double contents;
    private double liability;
    private double commission;

    public Home() {
    }

    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }

    public void setLastName(String lastName) {
        this.lastName = lastName;
    }

    public void setFootage(int footage) {
        this.footage = footage;
    }

    public void setDwelling(double dwelling) {
        this.dwelling = dwelling;
    }

    public void setContents(double contents) {
        this.contents = contents;
    }

    public void setLiability(double liability) {
        this.liability = liability;
    }

    public void computeCommission() {
        commission = (liability * 0.30) + ((dwelling + contents) * 0.20);
    }

    public String toString() {
        return "Home Policy\n-----------\n" +
                "Name: " + firstName + " " + lastName + "\n" +
                "Footage: " + footage + "\n" +
                "Dwelling: $" + String.format("%.2f", dwelling) + "\n" +
                "Contents: $" + String.format("%.2f", contents) + "\n" +
                "Liability: $" + String.format("%.2f", liability) + "\n" +
                "Commission: $" + String.format("%.2f", commission);
    }
}