public class Auto {
    private String firstName;
    private String lastName;
    private String make;
    private String model;
    private double liability;
    private double collision;
    private double commission;

    public Auto(String firstName, String lastName, String make, String model, double liability, double collision) {
        this.firstName = firstName;
        this.lastName = lastName;
        this.make = make;
        this.model = model;
        this.liability = liability;
        this.collision = collision;
    }

    public void computeCommission() {
        commission = (liability + collision) * 0.30;
    }

    public String toString() {
        return "Auto Policy\n-----------\n" +
                "Name: " + firstName + " " + lastName + "\n" +
                "Make: " + make + "\n" +
                "Model: " + model + "\n" +
                "Liability: $" + String.format("%.2f", liability) + "\n" +
                "Collision: $" + String.format("%.2f", collision) + "\n" +
                "Commission: $" + String.format("%.2f", commission);
    }
}